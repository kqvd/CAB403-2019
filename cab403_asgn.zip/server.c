//  403 Assignment
//  David Thai - n9994653
//  Kevin Duong - n9934731

#include <stdio.h> 
#include <netdb.h> 
#include <netinet/in.h> 
#include <stdlib.h> 
#include <string.h> 
#include <sys/socket.h> 
#include <sys/types.h> 
#include <unistd.h>
#include <stdbool.h>
#include <time.h>
#include <signal.h>
#define MAX 10000
#define MAX_LENGTH 1024
#define SA struct sockaddr 

typedef struct Channel
{
    int channelId;
    char ** messages;
    int numOfMessages;
    time_t ** timeReceived;
}Channel;

Channel listOfChannels[256];

typedef struct Client
{
    int clientId;
    int livefeed_channel;
    bool livefeed;
    bool livefeedAll;
    int channel_read[256][1];
    int numMsgWhenSub[256][1];
}Client;

Client client;

// Invalid Channel Id
char * invalid(int channel_id, char * buff){
    sprintf(buff, "Invalid channel: %d", channel_id);
    return buff;
}

// Not Subscribed to Channel
char * notSub(int channel_id, char * buff){
    sprintf(buff, "Not subscribed to channel: %d", channel_id);
    return buff;
}

// Subscribe the client to the given channel ID
void sub(int channel_id, int sockfd, char * buff){
    if(channel_id >= 0 && channel_id <= 255){
        bool sub = false;
        if(client.channel_read[channel_id][0] > -1){
            sub = true;
        }
        if(sub == true){
            sprintf(buff, "Already subscribed to channel: %d", channel_id);
            write(sockfd, buff, MAX);
        }else{
            // Subscribe client to channel
            client.channel_read[channel_id][0] = 0;
            client.numMsgWhenSub[channel_id][0] = listOfChannels[channel_id].numOfMessages;
            sprintf(buff, "Subscribed to channel: %d", channel_id);
            write(sockfd, buff, MAX);
            fprintf(stderr, "Client %d subscribed to channel %d\n", client.clientId, channel_id);
        }
    }else{
        strcpy(buff, invalid(channel_id, buff));
        write(sockfd, buff, MAX);
    }
}

// Show a list of subscribed channels and statistics
void channels(int sockfd, char * buff){
    int * channelsSubTo = malloc(256*sizeof(int));
    int counter = 0;
    // Getting subscribed channels
    for(int i = 0; i < 256; i++){
        if (client.channel_read[i][0] > -1){
            channelsSubTo[counter] = i;
            counter++;
        }
    }
    // No subscribed channels
    if (counter == 0){
        strcpy(buff, " ");
        write(sockfd, buff, MAX);
    }
    // Subscribed channels exists
    else{
        int totalMsg[counter];
        int msgRead[counter];
        int msgNotRead[counter];
        // Calculating stats
        for(int i = 0; i < counter; i++){
            totalMsg[i] = listOfChannels[channelsSubTo[i]].numOfMessages;
            msgRead[i] = client.channel_read[channelsSubTo[i]][0];
            msgNotRead[i] = totalMsg[i]-(client.numMsgWhenSub[channelsSubTo[i]][0]+msgRead[i]);
        }
        // Sending list to client
        char channelStat[40];
        for(int i = 0; i < counter; i++){
            sprintf(channelStat, "Channel %d:\t%d\t%d\t%d\n", channelsSubTo[i], totalMsg[i], msgRead[i], msgNotRead[i]);
            sprintf(buff, "%s\n%s", buff, channelStat);
        }
        write(sockfd, buff, MAX);
        fprintf(stderr, "List of channels sent to Client %d\n", client.clientId);
    }
    free(channelsSubTo);
}

// Unsubscribe the client to the given channel ID
void unsub(int channel_id, int sockfd, char * buff){
    if(channel_id >= 0 && channel_id <= 255){
        bool sub = true;
        if(client.channel_read[channel_id][0] < 0){
            sub = false;
        }
        if(sub == false){
            strcpy(buff, notSub(channel_id, buff));
            write(sockfd, buff, MAX);
        }else{
            client.channel_read[channel_id][0] = -1;
            sprintf(buff, "Unsubscribed from channel: %d", channel_id);
            write(sockfd, buff, MAX);
            fprintf(stderr, "Client %d unsubscribed from channel %d\n", client.clientId, channel_id);
        }
    }else{
        strcpy(buff, invalid(channel_id, buff));
        write(sockfd, buff, MAX);
    }
}

// Fetch and display next unread message from give channel Id
char * next_id(int channel_id, char * buff){
    if(channel_id >= 0 && channel_id <= 255){
        bool sub = true;
        if(client.channel_read[channel_id][0] < 0){
            sub = false;
        }
        if(sub == false){
            strcpy(buff, notSub(channel_id, buff));
            return buff;
        }else{
            int ref = client.numMsgWhenSub[channel_id][0] + client.channel_read[channel_id][0];
            if(ref < listOfChannels[channel_id].numOfMessages){
                char * msg = listOfChannels[channel_id].messages[ref];
                client.channel_read[channel_id][0] += 1;
                fprintf(stderr, "Next unread message from Channel %d sent to Client %d\n", channel_id, client.clientId);
                return msg;
            }else{
                strcpy(buff, " ");
                return buff;
            }
        }
    }else{
        strcpy(buff, invalid(channel_id, buff));
        return buff;
    }
}

// Continuous version of the NEXT command, displaying all unread
// messages on the given channel, then waiting, displaying new messages
// as they come in
void livefeed_id(int channel_id, int sockfd, char * buff){
    if(channel_id >= 0 && channel_id <= 255){
        bool sub = true;
        if(client.channel_read[channel_id][0] < 0){
            sub = false;
        }
        if(sub == false){
            strcpy(buff, notSub(channel_id, buff));
            write(sockfd, buff, MAX);
        }else{
            if(client.livefeed == false){
                fprintf(stderr, "Client %d livefeeds Channel %d\n", client.clientId, channel_id);
                client.livefeed = true;
                client.livefeedAll = false;
                strcpy(buff, "lf=on");
                write(sockfd, buff, MAX);
            }
            char * msg;
            char * allMsg = malloc(MAX*sizeof(char));
            int counter = 0;
            int ref = listOfChannels[channel_id].numOfMessages-(client.numMsgWhenSub[channel_id][0]+client.channel_read[channel_id][0]);
            while(counter <= ref){
                msg = next_id(channel_id, buff);
                sprintf(allMsg, "%s%s", allMsg, msg);
                counter += 1;
            }
            strcpy(buff, allMsg); 
            write(sockfd, buff, MAX);
            client.livefeed_channel = channel_id;
        }
    }else{
        strcpy(buff, invalid(channel_id, buff));
        write(sockfd, buff, MAX);
    }
}

// Display next unread message out of all subscribed channels
char * next(char * buff){
    char * channelsSubTo = malloc(256*sizeof(char));
    int counter = 0;
    // Getting subscribed channels
    for(int i = 0; i < 256; i++){
        if (client.channel_read[i][0] > -1){
            channelsSubTo[counter] = i;
            counter++;
        }
    }
    // No subscribed channels
    if (counter == 0){
        strcpy(buff, "Not subcribed to any channels");
        return buff;
    }
    // Subscribed channels exists
    else{
        time_t oldest = time(NULL);
        int channel = -1;
        int msgLocation = -1;
        for(int i = 0; i < counter; i++){
            int ref = client.numMsgWhenSub[channelsSubTo[i]][0] + client.channel_read[channelsSubTo[i]][0];
            if(ref < listOfChannels[channelsSubTo[i]].numOfMessages){
                time_t next = listOfChannels[channelsSubTo[i]].timeReceived[ref][0];
                if(next < oldest){
                    oldest = next;
                    channel = channelsSubTo[i];
                    msgLocation = ref;
                }
            }
        }
        if(channel > -1){
            char * msg = listOfChannels[channel].messages[msgLocation];
            sprintf(buff, "%d:%s", channel, msg);
            client.channel_read[channel][0] += 1;
            fprintf(stderr, "Next unread message from Channel %d sent to Client %d\n", channel, client.clientId);
            return buff;
        }else{
            strcpy(buff, " ");
            return buff;
        }
    }
    free(channelsSubTo);
}

// 
void livefeed(int sockfd, char * buff){
    int * channelsSubTo = malloc(256*sizeof(int));
    int counter = 0;
    // Getting subscribed channels
    for(int i = 0; i < 256; i++){
        if (client.channel_read[i][0] > -1){
            channelsSubTo[counter] = i;
            counter++;
        }
    }
    // No subscribed channels
    if (counter == 0){
        strcpy(buff, " ");
        write(sockfd, buff, MAX);
    }
    // Subscribed channels exists
    else{
        if(client.livefeedAll == false){
            fprintf(stderr, "Client %d livefeeds all channels\n", client.clientId);
            client.livefeedAll = true;
            client.livefeed = false;
            client.livefeed_channel = -1;
            strcpy(buff, "lf=on");
            write(sockfd, buff, MAX);
        }
        char * msg;
        char * allMsg = malloc(MAX*sizeof(char));
        int read = 0;
        int totalUnread = 0;
        for(int i = 0; i < counter; i++){
            int msgNotRead = client.numMsgWhenSub[channelsSubTo[i]][0] + client.channel_read[channelsSubTo[i]][0];
            totalUnread += listOfChannels[channelsSubTo[i]].numOfMessages - msgNotRead;
        }
        while(read <= totalUnread){
            msg = next(buff);
            sprintf(allMsg, "%s%s", allMsg, msg);
            read += 1;
        }
        strcpy(buff, allMsg); 
        write(sockfd, buff, MAX);
    }
    free(channelsSubTo);

}

// Send msg to a channel
void send_id(int channel_id, int sockfd, char * buff){
    if(channel_id >= 0 && channel_id <= 255){
        if(channel_id >= 0 && channel_id < 10){
            buff += 7;
        }else if(channel_id >= 10 && channel_id < 100){
            buff += 8;
        }else{
            buff += 9;
        }
        int ref = listOfChannels[channel_id].numOfMessages;
        strcpy(listOfChannels[channel_id].messages[ref], buff);
        listOfChannels[channel_id].timeReceived[ref][0] = time(NULL);
        listOfChannels[channel_id].numOfMessages += 1;
        strcpy(buff, " ");
        write(sockfd, buff, MAX);
        fprintf(stderr, "Client %d sent a message to channel %d\n", client.clientId, channel_id);
    }else{
        strcpy(buff, invalid(channel_id, buff));
        write(sockfd, buff, MAX);
    }
}

// Client exits gracefuly
void bye(int sockfd, char * buff){
    // send buffer to client
    write(sockfd, buff, MAX);
    close(sockfd);
    fprintf(stderr, "Client %d left.\n", client.clientId);
    // Unsubscribe to all channels
    client.clientId = -1;
    client.livefeed_channel = -1;
    for(int i = 0; i < 256; i++){
        client.channel_read[i][0] = -1;
    }
}

// Get Client Id
int getId(int sockfd, char * buff){
    strcpy(buff, "id?");
    write(sockfd, buff, MAX);
    bzero(buff, MAX);
    read(sockfd, buff, MAX);
    return atoi(buff);
}

// Extract Channel Id from msg
int getChannel(char * buff, int ref){
    buff += ref;
    return atoi(buff);
}

// Function designed for chat between client and server. 
void func(int sockfd)
{ 
    // Initialise buffer
    char buff[MAX];

    // Get clientId
    int client_id = getId(sockfd, buff);
    
    // Intialise Client
    client.clientId = client_id;
    client.livefeed_channel = -1;
    for(int i = 0; i < 256; i++){
        client.channel_read[i][0] = -1;
    }

    // // Initialise Channels
    for(int i = 0; i < 256; i++){
        listOfChannels[i].channelId = i;
        listOfChannels[i].numOfMessages = 0;
        listOfChannels[i].messages = malloc(MAX*sizeof(char*));
        listOfChannels[i].timeReceived = malloc(MAX_LENGTH*sizeof(char*));
        for(int j = 0; j < MAX_LENGTH; j++){
            listOfChannels[i].messages[j] = malloc(MAX_LENGTH*sizeof(char));
            listOfChannels[i].timeReceived[j] = malloc(sizeof(time_t));
        }  
    }
      
    // Infinite loop for chat 
    for (;;) { 
        
        // Checking for messages if livefeed is on
        if(client.livefeed == true){
            livefeed_id(client.livefeed_channel, sockfd, buff);
        }
        if(client.livefeedAll == true){
            livefeed(sockfd, buff);
        }

        // clear buffer for reading
        bzero(buff, MAX);
        
        // read the message from client and copy it in buffer 
        read(sockfd, buff, MAX); 

        // client turns livefeed off
        if (strncmp("lf=off", buff, 6) == 0){
            client.livefeed = false;
            client.livefeedAll = false;
            fprintf(stderr, "Client %d stops livefeeds\n", client.clientId);
            strcpy(buff, " ");
            write(sockfd, buff, MAX);
            bzero(buff, MAX);
            read(sockfd, buff, MAX);
        }

        // if msg contains "BYE" or "bye" then server exit and chat ended. 
        if (strncmp("BYE", buff, 3) == 0 || strncmp("bye", buff, 3) == 0) {
            bye(sockfd, buff);
            // Server opens up a connection
            break;
        }
        // if msg contains "SUB" or "sub" then implement SUB()
        else if (strncmp("SUB ", buff, 4) == 0 || strncmp("sub ", buff, 4) == 0){
            int channel_id = getChannel(buff, 4);
            bzero(buff, MAX);
            sub(channel_id, sockfd, buff);
        }
        // if msg contains "UNSUB" or "unsub" then implement SUB()
        else if(strncmp("UNSUB ", buff, 6) == 0 || strncmp("unsub ", buff, 6) == 0){
            int channel_id = getChannel(buff, 5);
            bzero(buff, MAX);
            unsub(channel_id, sockfd, buff);
        }
        // if msg contains "CHANNELS" or "channels" then implement SUB()
        else if(strncmp("CHANNELS", buff, 8) == 0 || strncmp("channels", buff, 8) == 0){
            bzero(buff, MAX);
            channels(sockfd, buff);
        }
        // if msg contains "NEXT <channel_id>" or "next <channel_id>" then implement next_id()
        else if(strncmp("NEXT ", buff, 5) == 0 || strncmp("next ", buff, 5) == 0){
            int channel_id = getChannel(buff, 5);
            bzero(buff, MAX);
            strcpy(buff, next_id(channel_id, buff));
            write(sockfd, buff, MAX);
        }
        // if msg contains "NEXT" or "next" then implement next()
        else if(strncmp("NEXT", buff, 4) == 0 || strncmp("next", buff, 4) == 0){
            bzero(buff, MAX);
            strcpy(buff, next(buff));
            write(sockfd, buff, MAX);
        }
        // if msg contains "LIVEFEED <channel_id>" or "livefeed <channel_id>" then implement livefeed_id()
        else if(strncmp("LIVEFEED ", buff, 9) == 0 || strncmp("livefeed ", buff, 9) == 0){
            int channel_id = getChannel(buff, 9);
            bzero(buff, MAX);
            livefeed_id(channel_id, sockfd, buff);
        }
        // if msg contains "LIVEFEED" or "livefeed" then implement SUB()
        else if(strncmp("LIVEFEED", buff, 8) == 0 || strncmp("livefeed", buff, 8) == 0){
            bzero(buff, MAX);
            livefeed(sockfd, buff);
        }
        // if msg contains "SEND <channel_id>" or "send <channel_id>" then implement send()
        else if(strncmp("SEND ", buff, 5) == 0 || strncmp("send ", buff, 5) == 0){
            int channel_id = getChannel(buff, 5);
            send_id(channel_id, sockfd, buff);
        }
        else{
            strcpy(buff, " ");
            write(sockfd, buff, MAX);
        }
    } 
} 

// Server exits gracefully upon receiving SIGNAL (ctrl + c)
void server_exit() {

    printf("\nServer exiting...\n");
    exit(1);
}

// Driver function 
int main(int argc, char *argv[]) 
{ 
    if (argc == 2 || argc == 1)  {

        int sockfd, connfd, len; 
        struct sockaddr_in servaddr, cli; 
  
        // socket create and verification 
        sockfd = socket(AF_INET, SOCK_STREAM, 0); 
        if (sockfd == -1) { 
            printf("Socket creation failed...\n"); 
            exit(0); 
        }
  
        // assign IP, PORT 
        servaddr.sin_family = AF_INET; 
        servaddr.sin_addr.s_addr = htonl(INADDR_ANY); 
        if (argc == 2) {
            servaddr.sin_port = htons(atoi(argv[1])); // Configurable Port
        } else {
            servaddr.sin_port = htons(12345); // Default Port
        }
  
        // Binding newly created socket to given IP and verification 
        if ((bind(sockfd, (SA*)&servaddr, sizeof(servaddr))) != 0) { 
            printf("Socket bind failed...\n"); 
            exit(0); 
        } 
  
        // Observe connections

        signal(SIGINT, server_exit);

        while (1) {
            // Now server is ready to listen and verification 
            if ((listen(sockfd, 5)) != 0) { 
                printf("Listen failed...\n"); 
                exit(0); 
            } 
            else
                printf("Server listening...\n"); 
            len = sizeof(cli); 

            // Accept the data packet from client and verification 
            connfd = accept(sockfd, (SA*)&cli, &len); 
            if (connfd < 0) { 
                printf("Server could not acccept client...\n");  
            } 
            else {
                printf("Server acccepts the client...\n"); 
            }
            func(connfd); 
        }

        // Free memory
        for(int i = 0; i < 256; i++){
            for(int j = 0; j < MAX_LENGTH; j++){
                free(listOfChannels[i].messages[j]);
                free(listOfChannels[i].timeReceived[j]);
            }
                free(listOfChannels[i].messages);
                free(listOfChannels[i].timeReceived);
        }

        // After chatting close the socket 
        close(sockfd);
    } else
        printf("Please enter a port number.\n"); 
} 
