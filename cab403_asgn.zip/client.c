//  403 Assignment
//  David Thai - n9994653
//  Kevin Duong - n9934731

#include <netdb.h> 
#include <stdio.h> 
#include <stdlib.h> 
#include <string.h> 
#include <sys/socket.h> 
#include <unistd.h>
#include <arpa/inet.h>
#include <time.h>
#include <stdbool.h>
#include <signal.h>
#define MAX 10000
#define SA struct sockaddr 

volatile bool livefeed = false;
volatile bool signalLF = false;

void sendID(int sockfd, int client_id, char* buff){
    if ((strncmp(buff, "id?", 3)) == 0) { 
        bzero(buff, sizeof(buff));
        sprintf(buff, "%d", client_id);
        write(sockfd, buff, sizeof(buff)); 
    }
}

void handler(int num) {
    if(livefeed == true){
        livefeed = false;
        printf("\nEnding Livefeed.\n");
        signalLF = true;
    }else{
        write(STDOUT_FILENO, "\nPlease enter 'BYE' or 'bye' to exit.\n", 39);
    }
}

void func(int sockfd, int client_id) 
{   
    char buff[MAX];
    int n;

    // Handling Ctrl+C
    signal(SIGINT, handler);

    bzero(buff, MAX);
    read(sockfd, buff, MAX);
    sendID(sockfd, client_id, buff);

    for (;;) { 

        // Turning off livefeed
        if(signalLF == true){
            strcpy(buff, "lf=off");
            write(sockfd, buff, MAX);
            signalLF = false;
        }

        // Checking for messages from livefeed
        if(livefeed == true){
            bzero(buff, MAX);
            read(sockfd, buff, MAX);
            if((strncmp(buff, " ", 1)) == 0){

            }else{
                printf("%s\n", buff);
            }
        }

        bzero(buff, MAX);  
        n = 0; 
        // Read user input
        while ((buff[n++] = getchar()) != '\n')
            ;
        // Send input to server
        write(sockfd, buff, MAX); 

        bzero(buff, MAX);  
        read(sockfd, buff, MAX);
        // Exit gracefully
        if (strncmp("BYE", buff, 3) == 0 || strncmp("bye", buff, 3) == 0) {
            printf("Client Exiting...\n"); 
            break;
        }
        // Send client ID when server asks for it
        sendID(sockfd, client_id, buff);
        if((strncmp(buff, "lf=on", 5)) == 0){
            livefeed = true;
            bzero(buff, MAX);
            read(sockfd, buff, MAX);
        }
        if((strncmp(buff, " ", 1)) == 0){

        }else{
            printf("%s\n", buff);
        }
        // Turning off livefeed
        if(signalLF == true){
            strcpy(buff, "lf=off");
            write(sockfd, buff, MAX);
            signalLF = false;
        }
    } 
} 
  
int main(int argc, char *argv[]) 
{ 

    // Hostname and Port number required
    if (argc == 3) {

        char *hostname = argv[1];
        int port = atoi(argv[2]);

        // Current time as seed for random generator
        srand(time(0));

        // Client ID
        int client_id = rand()%9999;

        int sockfd, connfd; 
        struct sockaddr_in servaddr, cli; 
  
        // socket create verification 
        sockfd = socket(AF_INET, SOCK_STREAM, 0); 
        if (sockfd == -1) { 
            printf("Socket creation failed...\n"); 
            exit(0); 
        }
        bzero(&servaddr, sizeof(servaddr)); 
  
        // assign IP, PORT 
        servaddr.sin_family = AF_INET; 
        servaddr.sin_addr.s_addr = inet_addr(hostname); // Hostname
        servaddr.sin_port = htons(port); // Port Number
  
        // connect the client socket to server socket 
        if (connect(sockfd, (SA*)&servaddr, sizeof(servaddr)) != 0) { 
            printf("Connection to the server failed...\n"); 
            exit(0); 
        } 
        else
            printf("Welcome! Your client ID is %d\n", client_id); 
  
        // function for chat 
        func(sockfd, client_id);
  
        // close the socket 
        close(sockfd); 

    } else
        printf("Please enter a hostname and port number.\n"); 
}